# Dataset Source Classes

Allowed source classes:
- internal canon documents
- internal prompt/config packs
- internal benchmark sets
- user-provided reference images
- approved generated outputs
- reviewed anti-reference / red-flag examples
- structured visual grammar research notes

Rules:
- do not duplicate copyrighted source content into the dataset index
- store source class, provenance, and relevance only
- keep external-source ingestion separated from canon-lock decisions
