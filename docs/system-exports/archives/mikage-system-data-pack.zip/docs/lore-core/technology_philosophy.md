# Technology Philosophy

## Relationship map

### Porcelain shell
- external dignity layer
- purity / order / surface perfection anchor
- cannot remain sterile forever; must show consequence when stressed

### Carbon frame
- reinforcement and internal structural logic
- links elegance to functional engineering
- supports mobility and survivability

### Titanium articulation
- mechanical joints and load-bearing movement system
- exposes engineering truth rather than hiding it behind fantasy smoothness

### Restrained crimson reactor
- internal energy source / system stress signal
- must remain contained, not decorative spectacle
- visually tied to cost, entropy, heat, and system consequence

### Fracture language
- damage is memory
- fracture is trace, consequence, and history
- kintsugi-like repair behavior is acceptable when it remains material and engineered

## Core synthesis
Mikage technology must always read as sacred-industrial hard sci-fi: pure surface, engineered substructure, visible consequence.
