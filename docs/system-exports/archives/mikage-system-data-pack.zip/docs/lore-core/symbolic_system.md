# Symbolic System

## Mask meaning
- sacred identity anchor
- dignity, controlled presence, and non-cartoon symbolic focus
- kitsune-linked visual shorthand exists, but interpretation must remain restrained and production-safe

## Fracture meaning
- memory
- consequence
- history carried in the material body
- evidence that power has cost

## Color meaning
- porcelain white: order, purity, sterile authority
- void black: discipline, control, emptiness, visual gravity
- visceral crimson: entropy, cost, heat, damage, combat signal

## Motifs and symbolic roles
- enso red combat ring = Mushin combat state indicator
- kitsune mask = sacred-industrial identity emblem
- fracture / repair = persistence under consequence
