# World Context

Status: canon-safe structured summary

## Confirmed world laws
- universe is hard sci-fi
- power must have biological and physical cost
- entropy and thermal consequence are mandatory system behaviors
- no magic, telekinesis, or supernatural willpower mechanics

## Confirmed ideological triangle
- White Monolith = absolute order
- ARCHON-IX = absolute chaos
- Mikage = controlled evolution

## Confirmed environmental poles
- White Monolith: sterile porcelain, perfect symmetry, clinical order
- Neon Grid: rust, cables, acid rain, neon glitch

## Placeholder fields
- PLACEHOLDER: detailed chronology of factions not present in provided source stack
- PLACEHOLDER: named city map and regional topology not present in provided source stack
