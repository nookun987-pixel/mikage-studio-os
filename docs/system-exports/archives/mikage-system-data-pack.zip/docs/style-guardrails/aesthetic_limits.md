# Aesthetic Limits

## Acceptable variation limits
Can vary within reviewable bounds:
- environment selection
- lighting emphasis
- camera distance / crop
- fashion/editorial emphasis
- material finish intensity

## What can change
- scene framing
- surface wear intensity
- amount of rain / haze / atmosphere
- editorial polish level
- orthographic vs cinematic presentation

## What cannot change
- Mikage core identity
- hard sci-fi causality
- porcelain / carbon / titanium hierarchy
- restrained crimson energy behavior
- palette anchors: porcelain white, void black, visceral crimson
- requirement for consequence / trace / fracture memory
- rejection of childish anime, fantasy magic, generic neon overload

## Identity preservation rules
1. Mikage must read as disciplined, elegant, and severe.
2. Beauty must remain controlled, never caricatured.
3. Damage must read as history, consequence, or system strain.
4. Technology must appear engineered, not mystical.
5. Composition must remain readable and intentional.
