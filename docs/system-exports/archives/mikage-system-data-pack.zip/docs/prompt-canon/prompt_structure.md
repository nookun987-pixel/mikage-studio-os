# Mikage Prompt Canon Structure

Status: normalized production scaffold
Project: Mikage Zenith
Source stack:
- `01_Mikage_Core_Spec.txt`
- `02_Mikage_3_Mode_Visual_Briefs.txt`
- `03_Mikage_Prompt_Pack.txt`
- `04_Studio_Test_Workflow.txt`
- `MIKAGE_PROJECT_MASTER.md`
- `MIKAGE_WORKFLOW_MASTER.md`
- `SYSTEM_MASTER.md`
- `MIKAGE — PROMPT COMPILER CONFIG PACK v1.md`
- `MIKAGE — CANON VALIDATOR RULE PACK v1.md`
- `MIKAGE — SEED DATA PACK v1.md`
- `MIKAGE — RUNTIME UPGRADE PACK v2.md`
- `MIKAGE_IP_ENGINE_GOVERNANCE_PATCH_v1.md`
- `Japanese Visual Aesthetics AI Knowledge Packs.md`
- `JAPANESE ART GRAMMAR FOR STUDIO.json`
- `JAPANESE_TRADITIONAL_VISUAL_REFERENCE.MASTER PACK.json`

## Standard prompt architecture
Use this block order unless a source preset explicitly removes a block:
1. identity / subject
2. mask / face anchor
3. material language
4. silhouette language
5. fracture / damage language
6. energy behavior
7. lighting language
8. camera language
9. environment language
10. composition intent
11. restrictions / canon anchors
12. output quality / render intent

## Order of prompt blocks
```txt
[SUBJECT]
[IDENTITY ANCHOR]
[MASK + HAIR]
[MATERIALS]
[SILHOUETTE]
[FRACTURE / TRACE]
[ENERGY / REACTOR]
[LIGHTING]
[CAMERA]
[ENVIRONMENT]
[COMPOSITION]
[RESTRICTIONS]
[OUTPUT INTENT]
```

## Canonical Mikage prompt writing format
```txt
Mikage, [identity anchor], wearing [mask block], built from [material block], with [silhouette block], showing [fracture block], with [energy block], under [lighting block], framed with [camera block], inside [environment block], composition emphasizing [composition intent], preserve [canon anchor], avoid [drift block], [output quality block]
```

## Required prompt block content
### Subject / identity
- Mikage
- calm introspective presence
- minimal emotion
- strong visual gravity
- restrained futuristic aesthetic

### Material
Prioritize this hierarchy:
1. porcelain / ceramic shell
2. carbon-fiber reinforcement / frame
3. dark or oxidized titanium articulation
4. restrained crimson energy traces

### Silhouette
- elegant severe functional silhouette
- agile hunter / high-mobility chassis when character-focused
- controlled readable outline
- no bulky fantasy exaggeration
- no childish proportion bias

### Lighting
- high-contrast chiaroscuro
- disciplined rim control
- restrained specular reflection on porcelain
- no bloom-heavy magical glow

### Camera
- anamorphic bias when cinematic
- controlled composition
- cold linear camera discipline
- no shaky-cam language

### Environment
- industrial megacity / brutalist / wet surface / cable density when urban
- void-black stage when reference isolation is needed
- environment must support hard-sci-fi consequence, not fantasy spectacle

### Restrictions
Always preserve:
- hard sci-fi causality
- palette anchors `#FAFAFA`, `#0A0A0A`, `#E60000`
- consequence / trace / fracture behavior
- Mikage identity dignity

Always reject:
- childish anime idol drift
- generic neon overload
- fantasy magic aesthetic
- ornamental overload
- composition clutter

## Short form prompt mode
Use when the system already injects config defaults.

Template:
```txt
Mikage, [identity], [materials], [silhouette], [lighting], [camera], [environment], preserve porcelain/void/crimson identity, no anime/fantasy/neon drift
```

## Full form prompt mode
Use for archive-ready runs, canon review, or vendor handoff.

Template:
```txt
Subject: Mikage
Identity: calm introspective presence, minimal emotion, strong visual gravity
Mask/Hair: glossy white kitsune mask, long black hair
Materials: porcelain ceramic shell, matte carbon fiber frame, oxidized titanium joints, restrained crimson internal energy
Silhouette: elegant severe, agile, readable, high-mobility
Fracture/Trace: fine fracture lines, consequence-bearing material memory, no sterile perfection
Lighting: high-contrast chiaroscuro, controlled rim, contained reflections
Camera: anamorphic discipline, linear framing, no shaky-cam
Environment: [specific scene constrained to hard-sci-fi logic]
Restrictions: preserve palette anchors, reject anime/fantasy/neon drift, reject ornamental overload, reject sexualized anatomy drift
Output: [reference / cinematic / audit intent]
```

## Prompt compile law
Every compiled run must return:
- positive prompt
- negative prompt
- sampler
- steps
- cfg
- seed rule
- lineage / receipt metadata

## Canon note
Three-mode test remains fixed for baseline studio batches:
- `canon_core`
- `luminous_fan_appeal`
- `luxury_mystical_editorial`

Additional operational modes in config are routing presets, not new lore.
