# Asset Folder Structure

```txt
assets/
  source/
    references/
    inputs/
    imported/
  draft/
    character/
    armor/
    weapon/
    mask/
    environment/
    prop/
    symbol/
    ui/
  approved/
    usable/
    canon-candidate/
  canon/
    locked/
    benchmark/
  export/
    packages/
    client/
    archive-ready/
  archive/
    deprecated/
    merged/
    superseded/
```

## Intent
- `source`: raw incoming material, never treated as canon by default
- `draft`: generated or structured working files
- `approved`: passed review but not fully canon-locked
- `canon`: hard-locked canon and benchmark assets
- `export`: releaseable packages and handoff bundles
- `archive`: retired, merged, deprecated, or historical records
