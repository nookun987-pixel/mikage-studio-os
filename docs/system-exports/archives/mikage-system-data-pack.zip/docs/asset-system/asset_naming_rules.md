# Asset Naming Rules

## Canonical naming format
```txt
mk_<asset_type>_<subject_or_system>_<descriptor>_v<major>_<minor>_<review_suffix>
```

Example:
```txt
mk_armor_mikage_front-orthographic_v1_0_pending
```

## Required components
- prefix: `mk`
- asset type: from `asset_types.json`
- subject or system: `mikage`, `zenith-blade`, `void-stage`, etc.
- descriptor: concise machine-safe slug
- version: `v<major>_<minor>`
- review suffix: one status suffix only

## Canonical prefixes
- `mk` = project asset
- `ref` = external or input reference
- `cfg` = config artifact
- `idx` = index file
- `os` = studio-os control file

## Variant rules
Use variant tokens only when the change is meaningful:
- `_front`
- `_side`
- `_back`
- `_three-quarter`
- `_detail`
- `_portrait`
- `_sheet`
- `_cinematic`
- `_audit`

## Review suffixes
- `pending`
- `reviewed`
- `usable`
- `canon-candidate`
- `locked`
- `deprecated`
- `merged`

## Export naming rules
Export packages should use:
```txt
mk_export_<package_name>_<yyyymmdd>_v<major>_<minor>
```

## Rules
- lowercase only
- use hyphen inside descriptor blocks, underscore between structural blocks
- no spaces
- no vendor name in canonical asset filename unless required by receipt metadata
- do not encode lore claims into filenames
